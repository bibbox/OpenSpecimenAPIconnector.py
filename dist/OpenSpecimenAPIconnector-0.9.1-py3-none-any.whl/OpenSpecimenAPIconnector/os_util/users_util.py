#Create User

payload = "{\"dnd\":"+dnd+",\"domainName\":\""+domainname+"\",\"instituteName\":\""+institutename+"\",\"type\":\""+type +\
            "\",\"firstName\":\""+firstname+"\",\"lastName\":\""+lastname+"\",\"emailAddress\":\""+emailaddress +\
            "\",\"phoneNumber\":\""+phonenumber+"\",\"loginName\":\"" + \
            loginname+"\",\"address\":\""+address+"\"}"

#Create password as superuser
payload = "{\"userId\":\"" + \
            str(userId)+"\",\"newPassword\":\""+newPassword+"\"}"

    #   assign role to users
payload = "{\n  \"site\":{\"id\":\""+str(siteid)+"\"},\n  \"collectionProtocol\":{\"id\":\""+str(
            cpid)+"\"},\n  \"role\":{\"name\":\""+role+"\"}\n}"    